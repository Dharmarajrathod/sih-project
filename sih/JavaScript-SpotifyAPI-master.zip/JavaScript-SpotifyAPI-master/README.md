# JavaScript-SpotifyAPI
This is a sample project showing how to call Spotify's API using vanilla JS
